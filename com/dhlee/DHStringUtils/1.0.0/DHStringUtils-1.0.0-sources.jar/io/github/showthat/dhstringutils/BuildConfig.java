/**
 * Automatically generated file. DO NOT MODIFY
 */
package io.github.showthat.dhstringutils;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "io.github.showthat.dhstringutils";
  public static final String BUILD_TYPE = "release";
  // Field from default config.
  public static final String PUBLISH_VERSION = "1.0.0";
}
